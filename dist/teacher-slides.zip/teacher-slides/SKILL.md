---
name: teacher-slides
description: Makes PPT / PowerPoint (.pptx) files and web slide decks - 파워포인트·피피티·발표자료·수업 PPT·홍보 PPT·보고 PPT - from a short spec, with a content recipe, a gate (blanks, overflow, empty-looking slides) and a preview picture. Use it first, before any generic pptx skill, when a teacher or anyone wants slides for lessons, training, parents, reports, company or club talks (회사·모임); the user's own template comes first.
license: Apache-2.0
---

# 교사 스튜디오 · 슬라이드

Teacher (no coding) asks in plain words for a PPT / talk / training / parent-meeting / club deck. You write a **short JSON spec**; tools design it, check it, and screenshot it.
Principle: tools guarantee the floor (type scale, contrast, safe margins, keep-all Korean, density), you add the message. Restraint beats decoration: one claim per slide, one accent colour. One claim is not one box: when the claim needs two or three pieces of evidence (the figures and the chart behind them, a drawing and the rule it shows), they sit together on that slide (`panel`).

Respond in the user's language. Follow the ask-first rule: `../teacher-studio/references/ask-first.md`.
The user's own template or reference comes first. (The user-template weapon - building from a PPT/design the user supplies - is planned, not built yet. Colours are covered: `shared/design/color_from.py deck.pptx --out pal.json`, then `"design": {"palette_from": "pal.json"}` in the spec, see `../teacher-studio/references/user-colors.md`; the composition stays ours. For type and layout learn from the file via `../teacher-studio/references/learn-from-reference.md` and say honestly that it is an approximation, not a copy.)

Content quality first: before writing any content read references/content-slides.md; pass the expert gate in shared/content/CONTENT-RULES.md.

## Words
- Never show code or file names to the teacher. 「PPT 만들어 줘」「칠판에 띄울 거」「글씨 더 크게」 -> `references/teacher-language.md`.
- **Editable PowerPoint** (「PPT」「파워포인트」「피피티」「.pptx」, or 「나중에 내가 고칠 거예요」) -> ALWAYS deliver an editable `.pptx` next to the web deck: add `--pptx` (same spec, same look; real text boxes, native charts and tables, speaker notes, QR as shapes). Say honestly what changes in PPT: 「단계별 나타나기·타이머·수식·아이콘 그림은 단순해져요」 and 「글꼴은 PC에 없으면 비슷한 글꼴로 바뀌어요」. python-pptx is installed on first need only after the teacher says yes (`shared/tools/ensure.py`, `--yes`). The teacher's own `.pptx/.potx` -> `--pptx --template mine.pptx` (their masters and layouts are used: template first). If the official `pptx` skill is listed by `doctor` (`official_doc_skills`) you may hand the file work to it for extras (animations, SmartArt, tracked edits); we still bring the structure, design and checks. PDF: 「Ctrl+P → PDF로 저장」.
- Intro video / countdown -> teacher-motion. Quiz game -> teacher-game.

## Pick the context from the request (one spec key)
`"context"`: **class** (수업·차시·학습 목표) · **promo** (홍보·모집·축제·알리기) · **public** (기관 보고·업무 보고·교육청·결과 보고) · **personal** (가족·자기소개·동호회·여행). It switches layouts, type scale, palette, numbering and slide defaults for the web deck and the .pptx; unsure -> ask once in the first question ("수업용 / 홍보용 / 기관 보고용 / 개인용"). Public = 표지(`org`,`date`,`dept`) + auto 목차 + `summary` + Ⅰ./1. + 개조식 + `table` + `source` on every data slide (required). Class = `objectives` + quiz/activity + `recap`. Promo = `hero` + CTA/QR. Personal = photo `hero`. Details, keys, sources: `references/context-recipes.md`. A user template still wins (`--template`, `palette_from`).

## A PowerPoint file was asked for (「PPT」「파워포인트」「.pptx」): the short path
One command builds the .pptx, checks it and draws the preview: `python3 scripts/deck.py --spec deck.json --pptx 발표.pptx --pptx-only --review review/` (drop `--pptx-only` and add `--out deck.html` when the web deck is wanted too).
1. Write the spec with the **content recipe** below (context, real structure, figures, check questions with answers). 「알아서」 = no questions: fill unknowns with stated assumptions.
2. Run the command. Read every `FIX` / `FAIL` / `NOTE` line.
3. **Look once**: open `review/<name>-approx-sheet.png` (all slides, drawn from the pptx: shapes, lines, tables, charts, pictures). Thin or plain slide -> give it its evidence (`diagram`, `table`, `chart`, `compare`, `activity`) or fold it into its neighbour as a `panel`; a slide that leaves half the screen empty, or three list slides in a row, is not finished. Never ship a text-only deck.
4. **Hard gate, last step, always:** rerun until the build prints `READY 발표.pptx`. `NOT DONE` / any `FAIL pptx:` line = not finished: fix the spec and run again (max 3 loops, then say plainly what still fails). Never write 「다 됐어요」 while it FAILs. A .pptx made or edited any other way (by hand, by another skill, after a fix request) goes through the same gate: `python3 scripts/pptx_check.py FILE.pptx --render review/` until `RESULT: PASS`.
5. Last message: the file in the folder the user named (current folder if they said so), what was assumed (one line), the 「바꿔 넣을 곳」 list only if the user wanted a template, and that the picture was an approximate preview.
Working alone or handing the job to a helper agent, the recipe and the gate travel with it: put this skill's name and step 4 in the hand-off.

## Content recipe (what makes the deck worth using)
- **Every body slide carries three things** (all contexts): a title that is the claim or the question, the evidence, and - where the audience could miss the point - the conclusion in one line (`"takeaway"`: a band under the body; works on `bullets` `compare` `steps` `timeline` `bignumbers` `table` `chart` `panel`). One kind of evidence that fills the screen -> the simple type. A claim that needs two kinds -> **`panel`** (2-4 blocks on one slide: `kpis` + `chart`, `diagram` + `cards` + `note`, `table` + `flow`, `tree` + `note` ...). Do not spread one claim over two thin slides, and do not put two claims in one panel.
- **Specific beats tidy.** Each slide names real things: the actual example, place, date, figure with its unit, the term as the textbook or the field writes it, a worked case. Text has two levels (a short heading + its detail: `cards` items `{title, items}`), not one long line per bullet. If a slide could be shown for another topic unchanged, it is not written yet.
- **The deck must not look the same on every slide.** Count the slide types after writing the spec: no type more than a third of the body, lists (`bullets`) at most a quarter, and no two neighbours with the same type and shape. The build prints a NOTE when this slips.
- **수업 (class):** a lesson deck needs four jobs done, in the order THIS lesson needs: say what will be learned (`objectives`), open a question, carry each idea, check and close (`quiz` with `answer` and `explain`, `activity` with minutes, `recap`; the .pptx adds ONE 「확인 문제 정답」 slide before the closing). **The outline comes from the unit, not from a list here**: write down the sub-topics the textbook gives this unit, then give each the slide its shape asks for (something drawn in the textbook -> `diagram`; two things side by side -> `compare` / `table`; an order -> `steps`; figures -> `bignumbers` / `chart`; one sentence to remember -> `statement`). Unsure of the type -> `"type": "auto"` and the build picks it from the content (`scripts/deck_shape.py`). Never drop a sub-topic to make room: when the user names a length (「10장 정도」) put `"target_slides": 10` in the spec (the build stops when the .pptx would run more than about a seventh over: 10 -> at most 12, 6 -> at most 7, the answers slide included) and merge neighbouring ideas on one slide. At least half of the idea slides are figures or side-by-side slides, not bullet lists; a drawing and the terms it shows belong on one slide (`panel`: `diagram` + `cards` + `note`), and the cover may carry a small drawing of the topic (`title.shapes`). Facts must be textbook-correct (definitions, units, signs, the direction of every cause and effect).
- **기관 보고 (public):** the reporter is the user's own place (「교육청 보고용」 = our school reports TO the office: `org` 「우리 학교」, not the office). Fixed by convention: 표지(`org`, `date`, `dept`), 목차, 요약 first. The body follows what was done, not a stock list: one `section` per real part of this work (배경·실적·성과·계획 are common names, use the ones this report has), and inside each the slide type follows the data (counts per group -> `table`; a change over time -> `chart`; two or three headline figures -> `bignumbers`; dated plans -> `timeline`; before / after -> `compare`), every one with `source`. Each content slide holds 4-6 lines or a table / chart (`section` entries only name the parts: the .pptx shows them in the header band, not as empty divider pages); more than half are not bullet lists. A report reader compares: put the headline figures and the chart or table behind them on ONE slide (`panel`: `kpis` + `chart`, `table` + `note`), draw who does what as a `tree` and how the work moves as a `flow`, and end data slides with the `takeaway` (what the numbers mean, not what they are). Numbers must agree with each other across slides (20/24 = 83.3 %); invented numbers are labelled on EVERY slide that shows one (요약·성과·건의 too: `source` or `footnote` 「예시 자료(가상 수치), 실제 집계로 교체」) and listed in the last message; a change is written with both ends (「운영 학교 비율 58 % → 81 %, 23 %p 증가」). 개조식 endings.
- **홍보 (promo):** one promise on the `hero`, then only what a reader needs to decide and act: why it is worth it (as many reasons as are real, not always three), the facts to act on (date, time, place: `table` or `timeline` when there are several), one call to action on the closing.
- **회사·모임·동호회 발표 (a look back, a meeting report, a club talk):** the room wants to know how it went and what happens next. Open with the few numbers that matter and their trend on one slide (`panel`: `kpis` + `chart`), name what worked and what did not with the cause of each (not a list of activities), and close with the next actions, each with who and by when (`table` / `timeline`). Invented figures are labelled 「예시(가상 수치)」 once on each slide that shows them and listed in the last message.
- **Unknown facts** (school name, presenter, phone): first choice = **leave them out** when the slide works without them (a lesson cover needs the grade, subject and unit, not a school or teacher name). Where the format needs one (기관 보고 표지의 기관·부서, 발신 명의) write the plausible value, never a slot: 「우리 학교」「교육연구부」, today's date `2026. 11. 20.`. Say the assumptions in one line at the end. Slots like `(학교명 입력)`, `○○학교`, `OOO`, `[...]`, `(예시)` FAIL the gate. Only when the user asks for blanks to fill in by hand: a labelled underline (`학교: ________`, `교사: ________`), never `○○` / `OO`, plus `"template_blanks": true` and the 「바꿔 넣을 곳」 list.

## Flow
1. **Ask only what is missing, once** (numbered, with defaults): ① who watches (grade / teachers / parents / club) ② topic or source file ③ length (default 10 slides) ④ mood in the teacher's words (따뜻하게, 깔끔하게, 신나게, 힙하게 ...) ⑤ date/presenter line.
2. **Outline table** (번호 | 종류 | 화면 글 | 메모) -> teacher says OK. Skip if they said 「바로 만들어」 (show the table with the result).
3. **Write the spec** (`deck.json`, below) and build:
```
python3 scripts/deck.py --spec deck.json --out deck.html --review review/ [--pptx]      # or: studio.py build slides --spec deck.json
```
   The seed is printed and stored in the file. A first build picks a fresh look; building the same spec file again (a fix round) keeps that look, so what was reviewed is what ships. `--fresh` picks a new look (say so: 「마음에 안 들면 다시 뽑아 드려요」), `--seed N` returns to a given one.
4. **Look.** Open `review/<name>-sheet.png` and judge every slide: *would a professional designer ship this?* Fix the spec (shorter text, other type, `--style`), rebuild, max 2 loops. `check_page.py` + `slides_review.py` must PASS (the build prints both).
5. Show the deck (artifact). Give three fixes in teacher words. Share / PDF / keep-offline lines: 「오른쪽 위 '게시' → 링크」「Ctrl+P → PDF로 저장(배경 그래픽 켜기)」「'다운로드'로 파일 보관, 인터넷 없이도 열려요」. Keys: → / click = next build, ← back, N notes, B black, F full screen, digits+Enter jump.

## Spec
```json
{"purpose":"수업|연수|학부모 설명회|발표|동아리|개인", "audience":"...", "mood":"따뜻하게", "subject":"과학",
 "title":"...", "seed": 7,                       // seed optional
 "design": {"style":"minimal-premium", "builds":true},   // optional overrides
 "slides":[ {"type":"title","title":"..","subtitle":"..","meta":"..","kicker":".."}, ... ]}
```
Words in `**stars**` are emphasised; `\n` breaks a line. Every slide may have `note` (presenter notes), `kicker`, `build:false`, `layout:"bullets.cards"` (force a variant).

| type | keys (limits) |
|---|---|
| title | title, subtitle, meta, shapes (optional: a small drawing of the topic beside the title, same shapes as `diagram`; not on a public cover) |
| section | title, sub |
| statement | text (one big sentence <= 70), sub |
| bullets | title, items 2-6 (<= 60 chars each) |
| compare | title, a:{label,items}, b:{label,items} or rows:[{k,a,b}] (<= 5) |
| steps | title, steps 3-6 [{title<=18,text<=44}] |
| bignumber | value, unit, caption |
| bignumbers | title, items 2-3 [{value,unit,caption}] (two big numbers side by side = compare) |
| quote | text, source |
| illustration | title, text, motif (Korean/Lucide word), art rings/blocks/arc — geometric, image-free |
| quiz | q, choices 2-5, answer (0-based), explain — next click reveals the answer |
| timeline | title, events 3-6 [{when,title,text}] |
| chart | title, kind bar/line/pie/doughnut, labels, series:[{name,data}], unit, takeaway (Chart.js, inlined) |
| math | tex (KaTeX), text |
| timer | minutes, title — start/pause/reset/±1 min, Space = start/pause |
| qr | url, title, caption — drawn at build time, offline |
| image | file (local path -> inlined, resized to <= 1920px / 3MB), title, caption |
| video | file (<= 8MB embedded, bigger -> 「영상 열기」 button), title |
| closing | title, sub, next[<=4], url (adds a QR) |
| table | title, columns 2-6, rows 1-8 (cells <= 40), unit, highlight, source, footnote |
| summary | title, text, label (핵심), points 2-5 |
| toc | title, items 2-8 (public: filled from sections) |
| hero | headline <= 34, sub, kicker, cta, url (QR), file (photo) |
| panel | title, blocks 2-4, takeaway, layout (`rows` / `cols` / `side`, default automatic). Block = `{"kind": ...}`: `kpis` items 2-4 {value, unit, caption} · `cards` items 2-6 {title, text or items[<=4]} (`"numbered": false` = a filled heading band instead of numbers: terms and their meaning, two sides, kinds) · `list` title, items 2-6 · `chart` chart (bar / line / pie / doughnut), labels, series, unit · `table` columns, rows 1-7, highlight · `note` text, label (the rule, the formula, the caution) · `flow` items 2-6 {title, text} (arrows between) · `tree` root, children 2-5 {title, items[<=3]} (organisation, classification) · `diagram` shapes. Any block may have a `title`. Wide kinds (kpis, flow, note, tree) take a full row, the others sit side by side. Public: `source` needed when a block holds numbers |
| diagram | title, shapes 2-40 on a 100 x 60 canvas: `line` `dash` `arrow` `dasharrow` {x1,y1,x2,y2,color,w} · `rect` {x,y,w,h,fill,text} · `circle` {cx,cy,r (or rx, ry for an oval),fill,text} · `poly` {points [[x,y],..] 3-12 corners, fill, color} (a mountain, a layer, a lens, a roof, a block arrow) · `arc` {cx,cy,r,from,to: degrees, 0 = right, 90 = up} · `label` {x,y,text,color,size s/m/l,align}; colours pr ac tx mu good bad water sky sun or #hex; points 0-4 (notes beside it), caption. Real lines and arrows in the .pptx. Example: `assets/spec-examples/context/class-light-reflection.json` |

**No blanks, ever.** Never write `[학교명]`, `(학교명 입력)`, `(…을 입력하세요)`, `[날짜]`, `20XX`, `OO초`, `OOO`, `○○학교`, `(예시)`, `(미정)`, `000-0000` in a spec. Fill with a plausible stated assumption (today's date, 2026학년도 / the current school year, generic 「우리 학교」·「3학년」) and say it in one line. Facts only the teacher knows (the real school name, phone, meeting date) go in `"fillins": ["학교 전화번호", ...]` (top-level list, words as they appear): the deck may then still contain them, and you show a short 「바꿔 넣을 곳」 list in the last message. Any other leftover is a FAIL (HTML review and `pptx_check.py`). **The user wins:** 「양식으로 해 줘」「빈칸 있는 틀로」「서식만」 -> spec `"template_blanks": true` (top level): all blanks stay, are reported as 「바꿔 넣을 곳」, and the build prints one caution line (`pptx_check.py --allow-blanks` for a lone file).
Rules: one message per slide, <= 330 characters of text on a slide (a `panel` may hold about 560), no emoji (stripped). Text is projection-sized (>= 28px) — never ask for smaller. Do not invent statistics; unsure facts -> note 「확인 필요」. No student names/photos.
Build errors are lists of 「고칠 곳」: fix exactly those and rerun. A date written with its weekday (`2026. 12. 5.(토)`, `12월 5일(토)`) is checked against the calendar; a wrong weekday stops the build.
Old `fire slides/lesson-deck/<skin>` (3 skins) still works but is the **lowest priority**: use it only if the teacher names a legacy look.

## Design language (automatic)
`scripts/deck_style.py` maps purpose + mood + subject to one of the 12 shared styles (`shared/design/styles.py`) and a palette; each style has its own composition (title treatment, card, emphasis, background motif, transition, preferred layout families). Every slide type has 2-4 layout variants (asymmetric splits, full-bleed type, bento cards, editorial rows, numbered steps, comparison panels); the picker never repeats a layout twice in a row. Use the user's logo/template colours first (`design.palette_from`; means, not our design). `slides_review.py` and `check` WARN when correct/wrong or chart colours look alike to colour-blind eyes (add shapes or text). Custom flair is allowed per slide and sandboxed: `"flair":{"css":"...","svg":"<svg>..</svg>"}` (no external urls, scripts, fixed positioning; css is scoped to that slide). Keep it rare.

## Review gate (`scripts/slides_review.py`)
**no placeholders left** (`placeholders.py`: `[대괄호]`, `20XX`, `OO`, `○○`, `000`, 학교명 ... FAIL unless listed in `fillins`) · External requests 0 · contrast >= 4.5 on real pixels · text >= 28px · overflow / safe margin / keep-all · not empty · **clutter caps** (elements <= 36, icons <= 3, big colours <= 5) · no 3 identical layouts in a row. Compare decks: `slides_review.py --compare a.html b.html` (distance >= 0.35).

## PowerPoint (.pptx) review - `scripts/pptx_check.py deck.pptx --spec deck.json --render review/`
`deck.py --pptx` builds the file, **shrinks text that would overflow its box** (never below 60% / 12pt; same metrics as the check, `pptx_fit.py`), then runs `pptx_check`: placeholders FAIL · text fit (estimate) FAIL · shapes inside the slide · no empty placeholder · **no empty-looking slide** (`pptx_fill.py`: a body slide whose content covers < 6 % of the slide or stops above 60 % of its height FAILs: add content or merge it) · **text large enough to project** (any text under 10pt FAILs, under 12pt is a NOTE) · **not one layout all the way** (NOTE when most body slides are plain text lists, on any .pptx). A FAIL on text fit means: shorten or split that slide in the spec and rebuild. The build ends with `READY file` only when every check passes, otherwise `NOT DONE`.
**Look at it.** `--review DIR` also draws PNGs: with **LibreOffice** installed it is a real rendering; otherwise it is an **approximate** preview drawn from the pptx itself (`pptx_draw.py`: shapes, lines and arrows, pictures, tables, native charts, groups, master art; red outline = estimated overflow). It works on any .pptx, so two decks can be compared with the same eyes. Always tell the teacher which one it was. LibreOffice is large (about 350MB download, 5-10 minutes): offer it once with the size (`py shared/tools/ensure.py libreoffice`, install only after a yes, `--yes-libreoffice`); declining is fine.
**Last message** (pipeline.md, Final checkpoint): file path, how to open it, check result, the 「바꿔 넣을 곳」 list.

## Absolute rules
1. **No student info** on slides. Example names are fictional.
2. **Facts**: unsure -> 「확인 필요」; sources of numbers go to the note.
3. **Copyright is advisory, not blocking** (`references/legal-advisory.md`): teacher's own images/quotes go in with one line of advice.
4. **Offline**: no external requests; fonts are embedded Noto Sans/Serif KR; old Chrome safe (no `?.` `??` `replaceAll` `:has` `aspect-ratio`).
5. Full-screen button and notes (N) stay; notes hidden by default.

## Files
| file | when |
|---|---|
| `scripts/deck.py` | build a deck (spec -> html, runs the checker) |
| `scripts/slides_review.py` | screenshots, contact sheet, metrics, `--compare` |
| `scripts/pptx_check.py`, `pptx_fill.py`, `pptx_render.py`, `pptx_draw.py`, `pptx_chart.py`, `pptx_fit.py`, `placeholders.py` | .pptx gate (blanks, text fit, empty-looking slides), PNG drawing (shapes, tables, charts, pictures), placeholder detector |
| `scripts/deck_diagram.py` | the `diagram` slide (web SVG + PowerPoint lines / arrows / shapes) |
| `scripts/deck_panel.py` | the `panel` slide (blocks, their arrangement, web + PowerPoint drawing) |
| `scripts/deck_layouts.py` | layout variants (read only to add one) |
| `assets/spec-examples/` | test fixtures, not patterns (they prove each slide type builds; never copy an outline, a heading or a look from them) |
| `references/teacher-language.md`, `legal-advisory.md` | wording, advice lines |
| `assets/missiles/lesson-deck/` + `scripts/build_stage.py` | legacy skins, hand-made stage pages (`--data/--show`), MP4 (`render_mp4.py`) |

## Pipeline (`../teacher-studio/references/pipeline.md`)
대본 = per-slide message + `note`; 콘티 = the Outline table in Flow step 2, or the thumbnail sheet: `py ../teacher-studio/scripts/storyboard.py deck.json --html sheet.html --open` (reads deck.json as is). Checkpoint: outline/콘티 before building, then the first deck; deliver with `deliver.py deck.html` (PDF, QR, privacy check for parent decks). Skip for 「바로/알아서」.

Design rules (type, spacing, colour, ornaments, the 5-point 「밤티 검사」 gate): [`shared/design/DESIGN-RULES.md`](shared/design/DESIGN-RULES.md)
