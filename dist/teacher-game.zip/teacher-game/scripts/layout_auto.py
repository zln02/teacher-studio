#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 박진영 (zln02)
"""Layout generator: picks a composition + component styles for a spec, so two builds do not look alike.

Principle: tools guarantee the quality floor (every layout declares its zones in assets/layouts/layouts.css, text never overlaps),
the AI adds request-specific creativity on top (design.words, custom_css, custom_svg, design.layout ...).

Choices (all deterministic from the spec + design.seed; build.py draws a fresh seed when the spec has none and prints/stores it):
  layout   quiz/escape/board question screens, ten footprints: stack | split (full) · bento · news (lower third) · poster (upper band) ·
           column (centre) · left | right (one side, the other left to the scene) · rail (headline + answer rail) · stair (diagonal)
  mech     per mechanic: match grid|scatter|shelf|brick - bingo grid|tilt|shelf - sort bins|shelves|conveyor - board snake|wave|stair
           survival row|bridge|stagger|arena - escape lockpos top|side
  choice   answer buttons: default | pill | tile | stamp | neon | note
  card     cards: default | round | ticket | polaroid | hex
  score    scoreboard: default | led | chalk | sticker | banner
  title    title treatment: default | outline | stack3d | stamp | underline (+ scale sm|md|lg, position center|left|top)
  transition  iris | wipe | fade
The CONTENT steers the layout too (content_features / layout_weights: OX share, answer and question length, pictures), so the composition follows
the material and the same request with another seed gets another skeleton.
Mood steers the weights (긴장감 -> dark split/news + neon; 귀엽게/따뜻하게 -> rounded bento; 고급스럽게 -> poster/news + ticket ...).
Spec overrides: design.layout, design.choice, design.card, design.score, design.title_style (also accepted: design.title).
Usage: python3 layout_auto.py --mechanic quiz --mood 긴장감 --seed 3
       python3 layout_auto.py --spec spec.json        # exactly what build.py will choose for this spec (same chooser, same words/title/seed)
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys

sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
import style_auto  # noqa: E402

for _s in (sys.stdout, sys.stderr):
    if hasattr(_s, "reconfigure"):
        _s.reconfigure(encoding="utf-8", errors="replace")

LAYOUTS = ["stack", "split", "bento", "news", "poster", "column", "left", "right", "rail", "stair"]
# the five newer footprints take their taste from the two older layouts they are closest to (styles only name the older five)
KIN = {"column": ("stack", "poster"), "left": ("split", "stack"), "right": ("split", "news"), "rail": ("news", "split"), "stair": ("bento", "poster")}
# when the content fits layouts with open space, the ones that cover most of the stage (and so overlap every other layout) are held back
# and the ones that leave a clear side or band free are preferred: measured footprint overlap with the other layouts, low -> high
SPREAD = {"news": 1.4, "left": 1.25, "right": 1.25, "rail": 1.2, "stair": 1.0, "column": 0.8, "poster": 0.8, "bento": 0.5, "stack": 0.25, "split": 0.25}
ROW_LAYOUTS = ("bento", "news", "poster", "rail", "stair")   # answers sit side by side or in a narrow rail: short answers only
SIDE_LAYOUTS = ("left", "right", "column")                   # one block of 58 % (2 x 2) or 70 % (slim bars): fine up to 22 characters
ESCAPE_OUT = ("news", "column", "left", "right")              # the lock strip takes 150px of height: news never, the side blocks only for short answers
MECH_VARIANTS = {"match": ["grid", "scatter", "shelf", "brick"], "bingo": ["grid", "tilt", "shelf"], "sort": ["bins", "shelves", "conveyor"],
                 "board": ["snake", "wave", "stair"], "survival": ["row", "bridge", "stagger", "arena"], "escape": ["top", "side"], "quiz": [""]}
CHOICES = ["default", "pill", "tile", "stamp", "neon", "note"]
CARDS = ["default", "round", "ticket", "polaroid", "hex"]
SCORES = ["default", "led", "chalk", "sticker", "banner"]
TITLES = ["default", "outline", "stack3d", "stamp", "underline"]
TRANSITIONS = ["iris", "wipe", "fade"]

# style families by mood word (substring match on design.mood + design.words + recipe); weights per option
FAMILY = {
    "tense": {"keys": ["긴장", "방탈출", "미스터리", "탐정", "추리", "tense"], "dark": True,
              "layout": {"split": 4, "news": 4, "poster": 1, "stack": 1, "bento": 1}, "choice": {"neon": 4, "tile": 2, "stamp": 2, "pill": 1},
              "card": {"ticket": 3, "default": 2, "hex": 2}, "score": {"led": 4, "banner": 2, "chalk": 1}, "title": {"stack3d": 3, "outline": 3, "stamp": 2}, "transition": {"wipe": 3, "fade": 1}},
    "cute": {"keys": ["귀여", "동화", "따뜻", "바다", "숲", "가족", "밝", "자연", "fairy", "warm", "sea", "forest"], "dark": False,
             "layout": {"bento": 4, "stack": 2, "poster": 2, "split": 1, "news": 1}, "choice": {"pill": 4, "note": 3, "tile": 1, "stamp": 1},
             "card": {"round": 4, "polaroid": 3, "default": 1}, "score": {"sticker": 4, "chalk": 2, "banner": 1}, "title": {"underline": 3, "stack3d": 2, "stamp": 2}, "transition": {"iris": 3, "fade": 2}},
    "luxe": {"keys": ["고급", "송년", "연말", "품격", "우아", "luxe"], "dark": True,
             "layout": {"poster": 4, "news": 3, "split": 2, "stack": 1, "bento": 1}, "choice": {"tile": 3, "pill": 2, "neon": 2},
             "card": {"ticket": 4, "default": 2, "polaroid": 1}, "score": {"banner": 4, "led": 2}, "title": {"underline": 4, "outline": 2, "stack3d": 1}, "transition": {"fade": 3, "wipe": 2}},
    "fun": {"keys": ["신남", "우주", "스포츠", "운동", "축제", "파티", "과학", "space", "sports"], "dark": False,
            "layout": {"split": 3, "bento": 3, "news": 2, "stack": 1, "poster": 2}, "choice": {"pill": 2, "neon": 2, "stamp": 2, "tile": 2, "note": 1},
            "card": {"hex": 3, "round": 2, "ticket": 2, "default": 1}, "score": {"led": 3, "sticker": 3, "banner": 2}, "title": {"stack3d": 3, "stamp": 3, "outline": 2}, "transition": {"iris": 2, "wipe": 2, "fade": 1}},
    "classic": {"keys": ["역사", "조선", "전통", "차분", "hanok"], "dark": False,
                "layout": {"poster": 3, "stack": 3, "split": 2, "news": 1, "bento": 1}, "choice": {"note": 3, "tile": 3, "stamp": 2, "pill": 1},
                "card": {"polaroid": 3, "ticket": 2, "default": 2}, "score": {"chalk": 3, "banner": 3, "sticker": 1}, "title": {"underline": 3, "stamp": 3, "outline": 1}, "transition": {"fade": 3, "wipe": 2}},
}
DEFAULT_FAMILY = {"dark": False, "layout": {k: 2 for k in LAYOUTS}, "choice": {k: 1 for k in CHOICES}, "card": {k: 1 for k in CARDS},
                  "score": {k: 1 for k in SCORES}, "title": {k: 1 for k in TITLES}, "transition": {k: 1 for k in TRANSITIONS}}


def _h(key: str) -> int:
    return int(hashlib.sha256(key.encode("utf-8")).hexdigest()[:10], 16)


def _pick(opts: dict, key: str) -> str:
    """Weighted deterministic pick."""
    total = sum(opts.values())
    r = _h(key) % total
    for k, w in sorted(opts.items()):
        if r < w:
            return k
        r -= w
    return next(iter(opts))


def family_for(text: str) -> tuple[str, dict]:
    for name, fam in FAMILY.items():
        if any(k in text for k in fam["keys"]):
            return name, fam
    return "", DEFAULT_FAMILY


def content_features(spec: dict) -> dict:
    """What the CONTENT looks like (so the composition follows the material, not one default skeleton): share of OX items, longest answer,
    longest question, how many answers a question usually has, whether pictures are used."""
    items = [it for it in (spec.get("items") or []) if isinstance(it, dict)]
    n = max(1, len(items))
    counts = [len(it.get("choices") or []) for it in items]
    multi = [c for c in counts if c >= 3]
    return {"ox": sum(1 for c in counts if c == 0) / n,
            "longest": max([len(str(c)) for it in items if len(it.get("choices") or []) >= 3 for c in it["choices"]] or [0]),
            "qlen": max([len(str(it.get("q") or it.get("question") or "")) for it in items] or [0]),
            "choices": round(sum(multi) / len(multi)) if multi else 0,
            "media": any(it.get("image") or it.get("svg") or it.get("img") for it in items),
            "phone": spec.get("device") == "phone"}


def side_answers(feat: dict) -> str:
    """How the answers sit in the side layouts (left / right / column): 'two' = 2 x 2 in a 58 % block (four answers of up to 10 characters),
    'list' = slim bars in a 70 % block (longer answers, or two / three of them)."""
    return "two" if feat["longest"] <= 10 and feat["choices"] == 4 else "list"


def layout_weights(style_w: dict, feat: dict, mech: str = "quiz") -> dict:
    """Layout weights = the style's preference (flattened, so one favourite does not win every time) x what the content can carry.

    - answers over 12 characters: no row / rail / stair (they would wrap to one-syllable lines); the side layouts switch to slim bars in a
      wider block and stay possible up to 22 characters
    - the question must fit its box: three lines (about 40 characters) in the side layouts and the stair, two (36) above four slim bars
    - mostly-OX sets want the big two-button layouts (poster / split / stair); long questions want a wide question card (stack / split)
    - the two full-stage layouts (stack, split) are held back whenever the content fits a layout with open space,
      so different requests do not all fill the same rectangle
    - escape games have 150px less height: fewer layouts, shorter limits
    - every layout the content allows stays possible, so the same request with another seed gets another skeleton."""
    w = {k: 0.7 for k in LAYOUTS}
    for k, v in style_w.items():
        w[k] = max(w.get(k, 0.7), float(v) ** 0.6)
    for k, (a, b) in KIN.items():
        w[k] = max(1.0, (w[a] + w[b]) / 2)
    if feat["longest"] > 12:
        for k in ROW_LAYOUTS:
            w[k] = 0
    if feat["longest"] > 10:  # the stair's 2 x 2 tiles are the narrowest two-line tiles (large type clips at 12)
        w["stair"] = 0
    if feat["longest"] > 22:
        for k in SIDE_LAYOUTS:
            w[k] = 0
    if feat.get("phone") and side_answers(feat) == "list":  # slim bars are under 44 CSS px on a phone held sideways
        for k in SIDE_LAYOUTS:
            w[k] = 0
    if feat["qlen"] > (36 if side_answers(feat) == "list" else 40):
        for k in SIDE_LAYOUTS:
            w[k] = 0
    if feat["qlen"] > 40:
        w["stair"] = 0
    if feat["qlen"] > 44:
        w["bento"] = 0
    if feat["qlen"] > 50:
        w["news"] = 0
    if mech == "escape":
        side_ok = feat["longest"] <= 9 and feat["qlen"] <= 40 and feat["choices"] == 4   # a 76 % block: two question lines, one-line answers
        for k in ESCAPE_OUT:
            if k == "news" or not side_ok:
                w[k] = 0
        if feat["qlen"] > 26:
            w["stair"] = 0
        if feat["longest"] > 7:
            w["rail"] = 0
        if feat["longest"] > 10:
            w["poster"] = 0
    if feat["choices"] >= 5:
        for k in ("column", "left", "right", "rail", "stair"):
            w[k] = 0
    if sum(1 for k, v in w.items() if v > 0 and k not in ("stack", "split")) >= 2:
        for k, f in SPREAD.items():
            w[k] *= f
    if feat["ox"] >= 0.5:
        w["poster"] *= 1.8
        w["split"] *= 1.5
        w["stair"] *= 1.3
        w["bento"] *= 0.5
    if feat["qlen"] > 44:
        w["stack"] *= 1.7
        w["split"] *= 1.4
        w["poster"] *= 0.5
        w["rail"] *= 0.5
    if feat["choices"] == 3:
        w["stack"] *= 1.4
        w["column"] *= 1.3
    if feat["media"]:
        w["split"] *= 1.6
        w["news"] *= 1.3
    out = {k: int(round(v * 10)) for k, v in w.items() if v > 0}
    return out or {"split": 1}


def request_signature(spec: dict) -> str:
    """A short fingerprint of WHAT was asked (title + the questions). It is mixed into every pick, so two different requests do not land on
    the same composition just because they share a mood word and a seed. The same spec + the same seed still gives the same game."""
    items = [it for it in (spec.get("items") or []) if isinstance(it, dict)]
    text = str(spec.get("title", "")) + "|" + "|".join(str(it.get("q") or it.get("question") or "") for it in items[:12])
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:8]


def compose(spec: dict, tokens: dict | None = None, recipe: str = "", style: str = "") -> dict:
    """The layout config stored in the page (SPEC.layoutCfg). Deterministic for (spec words, design.seed)."""
    d = spec.get("design") or {}
    mech = spec.get("mechanic", "quiz")
    words = " ".join(map(str, d.get("words") or [])) if isinstance(d.get("words"), list) else str(d.get("words") or "")
    text = " ".join([words, str(d.get("mood", "")), str(spec.get("title", "")), recipe])
    fname, fam = family_for(text)
    if style in style_auto.STYLES:  # the general style taxonomy decides (each style = its own composition language)
        fname, fam = style, style_auto.STYLES[style]
    seed = int(d.get("seed", 0))
    key = f"{mech}|{fname}|{seed}|{request_signature(spec)}"
    colors = (tokens or {}).get("colors") or {}
    dark = sum(int(colors.get("bg1", "#ffffff")[i:i + 2], 16) for i in (1, 3, 5)) < 330
    layout = d.get("layout") if d.get("layout") in LAYOUTS else _pick(layout_weights(fam["layout"], content_features(spec), mech), key + "L")
    choice_opts = dict(fam["choice"])
    if not dark:
        choice_opts.pop("neon", None)  # neon glow needs a dark scene
        choice_opts.setdefault("tile", 1)
    cfg = {
        "family": fname or "generic", "style": style if style in style_auto.STYLES else "", "css": (style_auto.STYLES[style].get("css", "") if style in style_auto.STYLES else ""), "seed": seed, "mechanic": mech, "layout": layout,
        "mech": _pick({v: 1 for v in MECH_VARIANTS.get(mech, [""])}, key + "M") if MECH_VARIANTS.get(mech) else "",
        "choice": d.get("choice") if d.get("choice") in CHOICES else _pick(choice_opts, key + "C"),
        "card": d.get("card") if d.get("card") in CARDS else _pick(fam["card"], key + "K"),
        "score": d.get("score") if d.get("score") in SCORES else _pick(fam["score"], key + "S"),
        "title": (d.get("title_style") or d.get("title")) if (d.get("title_style") or d.get("title")) in TITLES else _pick(fam["title"], key + "T"),  # design.title_style (docs) = design.title (older help)
        "titleScale": ["sm", "md", "lg"][_h(key + "Z") % 3], "tpos": ["center", "left", "top", "center"][_h(key + "P") % 4],
        "transition": _pick(fam["transition"], key + "X"),
    }
    feat = content_features(spec)
    # column / left / right: four short answers sit 2 x 2, anything longer (or two / three answers) becomes slim bars in a wider block
    cfg["ans"] = side_answers(feat) if layout in SIDE_LAYOUTS else ""
    if mech == "escape" and cfg["mech"] == "side":
        cfg["mech"] = "side"
    return cfg


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--mechanic", default="quiz")
    ap.add_argument("--mood", default="")
    ap.add_argument("--words", default="")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--spec", type=__import__("pathlib").Path, help="a spec.json: preview the look build.py will produce for it")
    a = ap.parse_args()
    if a.spec:
        import build  # lazy: build.py imports this module
        spec = json.loads(a.spec.read_text(encoding="utf-8"))
        spec.setdefault("design", {}).setdefault("seed", 0)
        if spec["design"].get("palette_from"):
            spec["design"]["palette_from"] = build.design.resolve_palette_from(spec["design"]["palette_from"], a.spec.resolve().parent)
        lay, th, au = build.layout_for(spec, build.make_tokens(spec))
        print(build.look_line(lay, au))
        print(json.dumps({"theme": th, **lay}, ensure_ascii=False, indent=1))
        return 0
    print(json.dumps(compose({"mechanic": a.mechanic, "design": {"mood": a.mood, "words": a.words.split(), "seed": a.seed}}), ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
